<?php if (!defined('ABSPATH')) exit; ?>
<style>
.ep-wrap{max-width:540px;margin:28px auto;background:#fff;border:1.5px solid #E2E8F0;border-radius:14px;padding:32px 28px;box-shadow:0 2px 12px rgba(0,0,0,.08);font-family:-apple-system,BlinkMacSystemFont,'Segoe UI',sans-serif;}
.ep-wrap h2{font-size:18px;font-weight:800;margin-bottom:4px;color:#0F172A;}
.ep-wrap p.sub{font-size:13px;color:#64748B;margin-bottom:20px;}
.ep-lbl{display:block;font-size:11px;font-weight:700;color:#475569;text-transform:uppercase;letter-spacing:.05em;margin-bottom:5px;}
.ep-inp{width:100%;padding:9px 12px;background:#F8FAFC;border:1.5px solid #E2E8F0;border-radius:8px;font-size:13px;font-family:inherit;color:#0F172A;outline:none;box-sizing:border-box;}
.ep-inp:focus{border-color:#3B82F6;box-shadow:0 0 0 3px rgba(59,130,246,.1);}
.ep-row{margin-bottom:12px;}
.ep-grid{display:grid;grid-template-columns:1fr 1fr;gap:12px;}
.ep-btn{width:100%;padding:11px;background:linear-gradient(135deg,#3B82F6,#8B5CF6);color:#fff;border:none;border-radius:8px;font-size:14px;font-weight:800;cursor:pointer;margin-top:8px;font-family:inherit;}
.ep-btn:hover{opacity:.9;}
.ep-btn:disabled{opacity:.5;cursor:not-allowed;}
.ep-ok{text-align:center;padding:24px;display:none;}
.ep-ok .ico{font-size:48px;}
.ep-ok h3{font-size:18px;font-weight:800;color:#059669;margin:10px 0 6px;}
.ep-ok p{font-size:13px;color:#64748B;}
.ep-err{background:#FEF2F2;border:1.5px solid #FECACA;border-radius:8px;padding:10px 13px;font-size:13px;color:#DC2626;font-weight:700;margin-bottom:10px;display:none;}
.ep-brand{display:flex;align-items:center;gap:10px;margin-bottom:18px;}
.ep-brand-ico{width:40px;height:40px;background:linear-gradient(135deg,#3B82F6,#8B5CF6);border-radius:11px;display:flex;align-items:center;justify-content:center;font-size:20px;}
.ep-brand-name{font-size:16px;font-weight:800;color:#0F172A;}
.ep-mascots{display:flex;gap:8px;justify-content:center;font-size:28px;margin-bottom:14px;}
@media(max-width:500px){.ep-grid{grid-template-columns:1fr;}}
</style>
<div class="ep-wrap">
  <div class="ep-brand">
    <div class="ep-brand-ico">🎓</div>
    <div class="ep-brand-name"><?php echo esc_html(get_option('eduportal_org_name', get_bloginfo('name'))); ?></div>
  </div>
  <div class="ep-mascots">👦 👨‍🎓 👩‍💼</div>
  <h2>Pendaftaran Anggota Baru</h2>
  <p class="sub">Isi data diri lengkap di bawah ini</p>

  <div class="ep-ok" id="ep-ok">
    <div class="ico">🎉</div>
    <h3>Pendaftaran Berhasil!</h3>
    <p>Data kamu sudah kami terima. Admin akan memverifikasi segera.</p>
  </div>

  <form id="ep-form">
    <div class="ep-err" id="ep-err"></div>
    <div class="ep-row"><label class="ep-lbl">Nama Lengkap *</label><input type="text" class="ep-inp" name="nama" placeholder="Nama sesuai kartu pelajar" required></div>
    <div class="ep-grid">
      <div class="ep-row"><label class="ep-lbl">Asal Sekolah *</label><input type="text" class="ep-inp" name="sekolah" placeholder="SMAN 1 Blitar" required></div>
      <div class="ep-row"><label class="ep-lbl">Kelas</label><input type="text" class="ep-inp" name="kelas" placeholder="XI IPA 2"></div>
    </div>
    <div class="ep-grid">
      <div class="ep-row"><label class="ep-lbl">No HP / WhatsApp</label><input type="tel" class="ep-inp" name="hp" placeholder="08xxxxxxxxxx"></div>
      <div class="ep-row"><label class="ep-lbl">Jenis Kelamin</label><select class="ep-inp" name="jk"><option>Laki-laki</option><option>Perempuan</option></select></div>
    </div>
    <div class="ep-row"><label class="ep-lbl">Email (opsional)</label><input type="email" class="ep-inp" name="email" placeholder="email@contoh.com"></div>
    <div class="ep-row"><label class="ep-lbl">Alamat</label><textarea class="ep-inp" name="alamat" rows="2" placeholder="Alamat lengkap"></textarea></div>
    <button type="submit" class="ep-btn" id="ep-sbmt">✨ Daftarkan Sekarang</button>
  </form>
</div>
<script>
document.getElementById('ep-form').addEventListener('submit', function(e) {
  e.preventDefault();
  var btn = document.getElementById('ep-sbmt');
  var err = document.getElementById('ep-err');
  btn.disabled = true; btn.textContent = '⏳ Memproses...';
  err.style.display = 'none';
  var fd = new FormData(this);
  fd.append('action','eduportal_daftar');
  fd.append('nonce','<?php echo wp_create_nonce("eduportal_nonce"); ?>');
  fetch('<?php echo esc_url(admin_url("admin-ajax.php")); ?>', {method:'POST',body:fd})
    .then(r=>r.json())
    .then(res=>{
      if (res.success) {
        document.getElementById('ep-form').style.display='none';
        document.getElementById('ep-ok').style.display='block';
      } else {
        err.textContent = res.data?.msg || 'Terjadi kesalahan';
        err.style.display='block';
      }
    })
    .catch(()=>{err.textContent='Gagal mengirim. Coba lagi.';err.style.display='block';})
    .finally(()=>{btn.disabled=false;btn.textContent='✨ Daftarkan Sekarang';});
});
</script>
