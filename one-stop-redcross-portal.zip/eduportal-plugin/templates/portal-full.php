<?php if (!defined('ABSPATH')) exit; ?>
<div id="eduportal-root" style="min-height:100vh;position:relative;font-family:-apple-system,BlinkMacSystemFont,'Segoe UI',sans-serif;">
  <div id="ep-init-loading" style="display:flex;align-items:center;justify-content:center;min-height:400px;flex-direction:column;gap:14px;">
    <div style="width:36px;height:36px;border:3px solid #DBEAFE;border-top-color:#3B82F6;border-radius:50%;animation:ep-spin .7s linear infinite;"></div>
    <p style="color:#94A3B8;font-family:-apple-system,sans-serif;font-weight:700;font-size:13px;">Memuat EduPortal...</p>
  </div>
</div>
<style>@keyframes ep-spin{to{transform:rotate(360deg)}}</style>
<script>
// EDUPORTAL_WP sudah di-inject oleh wp_localize_script di eduportal.php
// Kita tinggal baca dan override variabel di app
(function() {
  function epInit() {
    var wp = window.EDUPORTAL_WP;
    if (!wp) return;
    // Override dari WP Settings ke variabel app
    window.EP_ADMIN_PASS    = wp.adminPass    || 'admin123';
    window.EP_ANGGOTA_PASS  = wp.anggotaPass  || 'anggota123';
    window.EP_ORG           = wp.orgName      || 'EduPortal';
    window.EP_SHEETS_URL    = wp.sheetsUrl    || '';
    window.EP_AJAX_URL      = wp.ajaxUrl      || '';
    window.EP_NONCE         = wp.nonce        || '';
    window.EP_DAFTAR_URL    = wp.daftarUrl    || '';
    window.EP_WP_MODE       = true;

    // Sembunyikan loading indicator
    var el = document.getElementById('ep-init-loading');
    if (el) el.style.display = 'none';
  }
  // Jalankan setelah seluruh script dimuat
  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', epInit);
  } else {
    epInit();
  }
})();
</script>
