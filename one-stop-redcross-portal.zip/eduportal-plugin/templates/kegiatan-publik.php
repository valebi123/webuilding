<?php
if (!defined('ABSPATH')) exit;
global $wpdb;
$today    = current_time('Y-m-d');
$kegiatan = $wpdb->get_results($wpdb->prepare(
    "SELECT * FROM {$wpdb->prefix}eduportal_kegiatan WHERE tgl >= %s ORDER BY tgl ASC LIMIT 12", $today
), ARRAY_A);
$bulan = ['Jan','Feb','Mar','Apr','Mei','Jun','Jul','Ags','Sep','Okt','Nov','Des'];
$tc    = ['Pembelajaran'=>'#8B5CF6','Latihan'=>'#10B981','Rapat'=>'#F59E0B','Kegiatan Luar'=>'#EF4444','Evaluasi'=>'#94A3B8'];
?>
<style>
.ep-keg-wrap{font-family:-apple-system,BlinkMacSystemFont,'Segoe UI',sans-serif;max-width:700px;margin:0 auto;}
.ep-keg-title{font-size:18px;font-weight:800;color:#0F172A;margin-bottom:16px;}
.ep-keg-card{display:flex;gap:14px;background:#fff;border:1.5px solid #E2E8F0;border-radius:10px;padding:14px;margin-bottom:10px;transition:border-color .15s;align-items:flex-start;}
.ep-keg-card:hover{border-color:#3B82F6;}
.ep-keg-dt{background:#EFF6FF;border-radius:8px;width:50px;flex-shrink:0;text-align:center;padding:7px 5px;}
.ep-keg-day{font-size:20px;font-weight:900;color:#3B82F6;line-height:1;}
.ep-keg-mon{font-size:10px;text-transform:uppercase;color:#1D4ED8;font-weight:700;}
.ep-keg-nm{font-size:13px;font-weight:800;color:#0F172A;margin-bottom:5px;}
.ep-keg-meta{font-size:12px;color:#64748B;display:flex;gap:10px;flex-wrap:wrap;font-weight:600;align-items:center;}
.ep-keg-desc{font-size:12px;color:#94A3B8;margin-top:5px;font-weight:600;}
.ep-bdg{display:inline-flex;padding:2px 9px;border-radius:100px;font-size:11px;font-weight:700;}
.ep-empty{text-align:center;padding:32px;background:#F8FAFC;border:1.5px dashed #E2E8F0;border-radius:10px;font-size:13px;color:#94A3B8;font-weight:700;}
</style>
<div class="ep-keg-wrap">
  <div class="ep-keg-title">📅 Kegiatan Mendatang</div>
  <?php if (empty($kegiatan)): ?>
    <div class="ep-empty">Belum ada kegiatan terjadwal 😊</div>
  <?php else: foreach($kegiatan as $k):
    $d = new DateTime($k['tgl']);
    $warna = $tc[$k['tipe']] ?? '#94A3B8';
  ?>
  <div class="ep-keg-card">
    <div class="ep-keg-dt">
      <div class="ep-keg-day"><?php echo $d->format('d'); ?></div>
      <div class="ep-keg-mon"><?php echo $bulan[(int)$d->format('m')-1]; ?></div>
    </div>
    <div style="flex:1">
      <div class="ep-keg-nm"><?php echo esc_html($k['nama']); ?></div>
      <div class="ep-keg-meta">
        <span>⏰ <?php echo esc_html($k['waktu']); ?></span>
        <span>📍 <?php echo esc_html($k['lokasi']); ?></span>
        <span class="ep-bdg" style="background:<?php echo $warna; ?>22;color:<?php echo $warna; ?>"><?php echo esc_html($k['tipe']); ?></span>
      </div>
      <?php if ($k['desk']): ?>
        <div class="ep-keg-desc"><?php echo esc_html($k['desk']); ?></div>
      <?php endif; ?>
    </div>
  </div>
  <?php endforeach; endif; ?>
</div>
