/* One-Stop Red Cross Portal v5 - JS */
'use strict';

// ════════════════════════════════
// CONFIG
// ════════════════════════════════
var CFG = {
  org:       localStorage.getItem('ep_org')        || 'One-Stop Red Cross Portal',
  adminPass: localStorage.getItem('ep_adm_pass')   || 'admin123',
  sheetsUrl: localStorage.getItem('ep_sheets_url') || '',
  sheetsId:  localStorage.getItem('ep_sheets_id')  || '',
};

// Field config untuk form daftar (bisa diatur admin)
var DEF_FIELDS = [
  {key:'nama',    label:'Nama Lengkap',    type:'text',    enabled:true,  required:true,  locked:true},
  {key:'sekolah', label:'Asal Sekolah',    type:'text',    enabled:true,  required:true,  locked:false},
  {key:'kelas',   label:'Kelas',           type:'text',    enabled:true,  required:false, locked:false},
  {key:'hp',      label:'No HP/WhatsApp',  type:'tel',     enabled:true,  required:false, locked:false},
  {key:'jk',      label:'Jenis Kelamin',   type:'select',  enabled:true,  required:false, locked:false, opts:['Laki-laki','Perempuan']},
  {key:'email',   label:'Email',           type:'email',   enabled:false, required:false, locked:false},
  {key:'alamat',  label:'Alamat',          type:'textarea',enabled:false, required:false, locked:false},
  {key:'tgl_lahir',label:'Tanggal Lahir',  type:'date',    enabled:false, required:false, locked:false},
  {key:'asal_kota',label:'Asal Kota',      type:'text',    enabled:false, required:false, locked:false},
  {key:'no_induk', label:'No. Induk Siswa',type:'text',    enabled:false, required:false, locked:false},
];
var FC = JSON.parse(localStorage.getItem('ep_fc') || 'null') || DEF_FIELDS;

// ════════════════════════════════
// STATE
// ════════════════════════════════
var S = {
  akun: JSON.parse(localStorage.getItem('ep_akun') || 'null') || {
    admin:{id:'admin',username:'admin',password:'admin123',role:'admin',nama:'Administrator',sekolah:'',kelas:'',hp:'',jk:'',email:'',tgl:new Date().toISOString().split('T')[0],status:'aktif'},
  },
  kas:[
    {id:1,tgl:'2025-06-05',ket:'Iuran bulan Juni',kategori:'Iuran Anggota',jenis:'masuk',jumlah:150000},
    {id:2,tgl:'2025-06-07',ket:'Beli ATK',kategori:'ATK',jenis:'keluar',jumlah:35000},
    {id:3,tgl:'2025-06-10',ket:'Sumbangan alumni',kategori:'Sumbangan',jenis:'masuk',jumlah:200000},
    {id:4,tgl:'2025-06-15',ket:'Konsumsi rapat',kategori:'Konsumsi',jenis:'keluar',jumlah:80000},
  ],
  kegiatan:[
    {id:1,nama:'Latihan Dasar PMR',tgl:'2025-07-05',waktu:'08:00',lokasi:'Aula Sekolah',tipe:'Latihan',desk:'Latihan dasar P3K'},
    {id:2,nama:'Rapat Koordinasi',tgl:'2025-07-12',waktu:'13:00',lokasi:'Ruang Guru',tipe:'Rapat',desk:'Evaluasi program'},
    {id:3,nama:'Simulasi P3K',tgl:'2025-06-20',waktu:'09:00',lokasi:'Lapangan',tipe:'Pembelajaran',desk:''},
  ],
  templates:[
    {id:1,nama:'Surat Keterangan Aktif',tipe:'surat',desc:'Surat keterangan anggota aktif',
     isi:"SURAT KETERANGAN AKTIF\n\nYang bertanda tangan di bawah ini menerangkan bahwa:\n\nNama       : {{NAMA}}\nJabatan    : {{JABATAN}}\nOrganisasi : {{ORGANISASI}}\n\nAdalah benar merupakan anggota aktif {{ORGANISASI}}.\nDibuat untuk keperluan {{KEPERLUAN}}.\n\nDemikian surat keterangan ini dibuat.\n\n{{KOTA}}, {{TANGGAL}}\nKetua {{ORGANISASI}}",
     by:'Admin',tgl:'2025-06-01'},
    {id:2,nama:'Surat Undangan Kegiatan',tipe:'undangan',desc:'Template undangan kegiatan',
     isi:"SURAT UNDANGAN\n\nKepada Yth.\nSdr/i {{NAMA}}\ndi Tempat\n\nKami {{ORGANISASI}} mengundang Anda hadir dalam:\n\nKegiatan : {{KEPERLUAN}}\nTanggal  : {{TANGGAL}}\nLokasi   : {{LOKASI}}\n\nAtas kehadiran Anda, kami ucapkan terima kasih.\n\nHormat kami,\n{{ORGANISASI}}",
     by:'Admin',tgl:'2025-06-01'},
  ],
  absensi:[],history:[],docHistory:[],
  kasFilter:'all',kegFilter:'all',
  curTpl:null,
  dData:{},
};

var me = null;
var dStep = 1;
var angFiltered = [];
var akunFiltered = [];

// ════════════════════════════════
// STORAGE
// ════════════════════════════════
function saveAkun(){ try{localStorage.setItem('ep_akun',JSON.stringify(S.akun));}catch(e){} }
function getAkunList(){ return Object.values(S.akun).sort(function(a,b){return new Date(b.tgl)-new Date(a.tgl);}); }
function getAnggota(){ return getAkunList().filter(function(a){return a.role==='anggota';}); }

// ════════════════════════════════
// AUTH — REGISTER
// ════════════════════════════════
function switchTab(tab, btn){
  document.querySelectorAll('.auth-tab').forEach(function(b){b.classList.remove('act');});
  if(btn) btn.classList.add('act');
  else document.querySelectorAll('.auth-tab')[tab==='login'?0:1].classList.add('act');
  var tl=document.getElementById('tab-login'), td=document.getElementById('tab-daftar');
  if(tl) tl.classList.toggle('hide', tab!=='login');
  if(td) td.classList.toggle('hide', tab!=='daftar');
  if(tab==='daftar'){ dStep=1; renderDStep(1); renderDFields(); }
  clrErr();
}

function clrErr(){
  ['login-err','daftar-err','daftar-ok'].forEach(function(id){
    var el=document.getElementById(id); if(el)el.classList.add('hide');
  });
}

function showErr(id,msg){
  var el=document.getElementById(id); if(!el)return;
  el.textContent=msg; el.classList.remove('hide');
}

function tgPw(id,btn){
  var inp=document.getElementById(id); if(!inp)return;
  if(inp.type==='password'){inp.type='text';btn.textContent='🙈';}
  else{inp.type='password';btn.textContent='👁';}
}

function chkUser(v){
  var el=document.getElementById('usr-chk'); if(!el)return;
  if(!v){el.textContent='';return;}
  if(v.length<4){el.textContent='⚠️ Min. 4 karakter';el.style.color='var(--red)';return;}
  if(!/^[a-z0-9_]+$/.test(v)){el.textContent='⚠️ Hanya huruf kecil, angka, underscore';el.style.color='var(--red)';return;}
  if(S.akun[v]){el.textContent='❌ Username sudah digunakan';el.style.color='var(--red)';return;}
  el.textContent='✅ Username tersedia';el.style.color='var(--green)';
}

function chkPw(v){
  var fill=document.getElementById('pw-fill'), msg=document.getElementById('pw-msg'); if(!fill||!msg)return;
  var s=0;
  if(v.length>=6)s++;if(v.length>=10)s++;if(/[A-Z]/.test(v))s++;if(/[0-9]/.test(v))s++;if(/[^A-Za-z0-9]/.test(v))s++;
  var pct=(s/5)*100;
  var cols=['','#EF4444','#F97316','#F59E0B','#10B981','#059669'];
  var lbls=['','Sangat Lemah','Lemah','Cukup','Kuat','Sangat Kuat'];
  fill.style.width=pct+'%'; fill.style.background=cols[s]||'#EF4444';
  msg.textContent=v?(lbls[s]||''):''; msg.style.color=cols[s]||'var(--text3)';
}

function renderDFields(){
  var el=document.getElementById('daftar-fields'); if(!el)return;
  var active=FC.filter(function(f){return f.enabled;});
  el.innerHTML=active.map(function(f){
    var req=f.required?'<span style="color:var(--red)">*</span>':'';
    var inp='';
    if(f.type==='select') inp='<select class="inp" id="df-'+f.key+'">'+f.opts.map(function(o){return'<option>'+o+'</option>';}).join('')+'</select>';
    else if(f.type==='textarea') inp='<textarea class="inp" id="df-'+f.key+'" rows="2" placeholder="'+f.label+'"></textarea>';
    else inp='<input class="inp" type="'+f.type+'" id="df-'+f.key+'" placeholder="'+f.label+'">';
    return'<div class="fg"><label class="lbl">'+f.label+' '+req+'</label>'+inp+'</div>';
  }).join('')||'<div class="c3 fs-13 fw-7" style="text-align:center;padding:14px">Tidak ada field tambahan</div>';
}

function renderDStep(s){
  [1,2,3].forEach(function(i){
    var dot=document.getElementById('sd'+i), sec=document.getElementById('ds'+i);
    if(dot) dot.className='step-dot'+(i<s?' done':i===s?' active':'');
    if(sec) sec.classList.toggle('hide',i!==s);
  });
  dStep=s;
}

function dNext(from){
  clrErr();
  if(from===1){
    var user=(document.getElementById('d-usr')||{}).value||''; user=user.trim().toLowerCase();
    var pw=(document.getElementById('d-pw')||{}).value||'';
    var pw2=(document.getElementById('d-pw2')||{}).value||'';
    if(!user||user.length<4) return showErr('daftar-err','Username minimal 4 karakter');
    if(!/^[a-z0-9_]+$/.test(user)) return showErr('daftar-err','Username hanya huruf kecil, angka, underscore');
    if(S.akun[user]) return showErr('daftar-err','Username sudah digunakan');
    if(!pw||pw.length<6) return showErr('daftar-err','Password minimal 6 karakter');
    if(pw!==pw2) return showErr('daftar-err','Konfirmasi password tidak cocok');
    S.dData={username:user,password:pw};
    renderDStep(2);
  } else if(from===2){
    var active=FC.filter(function(f){return f.enabled;});
    var missing=[];
    active.forEach(function(f){
      var el=document.getElementById('df-'+f.key);
      var val=el?el.value.trim():'';
      S.dData[f.key]=val;
      if(f.required&&!val) missing.push(f.label);
    });
    if(missing.length) return showErr('daftar-err','Field wajib belum diisi: '+missing.join(', '));
    // Build review
    var rev='<strong>👤 Akun:</strong> @'+S.dData.username+'<br>';
    active.forEach(function(f){ if(S.dData[f.key]) rev+='<strong>'+f.label+':</strong> '+S.dData[f.key]+'<br>'; });
    var er=document.getElementById('daftar-review'); if(er)er.innerHTML=rev;
    renderDStep(3);
  }
}

function dBack(from){ clrErr(); renderDStep(from-1); }

function submitDaftar(){
  var btn=document.getElementById('daftar-btn');
  if(btn){btn.disabled=true;btn.textContent='⏳...';}
  clrErr();
  var d=S.dData;
  if(!d.nama) d.nama=d.username;
  var newAkun={
    id:d.username,username:d.username,password:d.password,
    role:'anggota',nama:d.nama||d.username,
    sekolah:d.sekolah||'',kelas:d.kelas||'',hp:d.hp||'',
    jk:d.jk||'',email:d.email||'',alamat:d.alamat||'',
    tgl_lahir:d.tgl_lahir||'',asal_kota:d.asal_kota||'',no_induk:d.no_induk||'',
    tgl:new Date().toISOString().split('T')[0],status:'pending',
  };
  S.akun[d.username]=newAkun;
  saveAkun(); updBadge();
  setTimeout(function(){
    if(btn){btn.disabled=false;btn.textContent='✅ Daftar';}
    var ok=document.getElementById('daftar-ok');
    if(ok){ok.textContent='🎉 Pendaftaran berhasil! Akun aktif setelah diverifikasi Admin.';ok.classList.remove('hide');}
    ['d-usr','d-pw','d-pw2'].forEach(function(id){var el=document.getElementById(id);if(el)el.value='';});
    S.dData={};
    renderDStep(1);
  },400);
}

// ════════════════════════════════
// AUTH — LOGIN / LOGOUT
// ════════════════════════════════
function doLogin(){
  var user=(document.getElementById('l-user')||{}).value||''; user=user.trim().toLowerCase();
  var pw=(document.getElementById('l-pass')||{}).value||'';
  clrErr();
  if(user==='admin'&&pw===CFG.adminPass){
    me=S.akun['admin']||{username:'admin',role:'admin',nama:'Administrator',status:'aktif'};
    me.role='admin'; startApp(); return;
  }
  var acc=S.akun[user];
  if(!acc||acc.password!==pw) return showErr('login-err','Username atau password salah');
  if(acc.status==='pending') return showErr('login-err','⏳ Akun menunggu verifikasi Admin');
  if(acc.status==='nonaktif') return showErr('login-err','❌ Akun dinonaktifkan. Hubungi Admin');
  me=acc; startApp();
}

function startApp(){
  document.getElementById('auth-screen').style.display='none';
  document.getElementById('app').style.display='block';
  document.body.className='is-'+(me.role||'anggota');
  var av=document.getElementById('uav'),nm=document.getElementById('unm'),rl=document.getElementById('urol');
  if(av){av.textContent=((me.nama||me.username||'?')[0]).toUpperCase();av.style.background=me.role==='admin'?'linear-gradient(135deg,#3B82F6,#8B5CF6)':'linear-gradient(135deg,#10B981,#3B82F6)';}
  if(nm)nm.textContent=me.nama||me.username;
  if(rl){rl.textContent=me.role==='admin'?'Admin':'Anggota';rl.className='user-rl '+(me.role==='admin'?'rl-admin':'rl-anggota');}
  var wb=document.getElementById('wb-msg'); if(wb)wb.textContent='Halo, '+(me.nama||me.username)+'! 🎉';
  var so=document.getElementById('sb-org'),ao=document.getElementById('auth-org');
  if(so)so.textContent=CFG.org; if(ao)ao.textContent=CFG.org;
  var td=document.getElementById('tdate'); if(td)td.textContent=new Date().toLocaleDateString('id-ID',{weekday:'short',year:'numeric',month:'long',day:'numeric'});
  var today=new Date().toISOString().split('T')[0];
  ['k-tgl','kg-tgl'].forEach(function(id){var el=document.getElementById(id);if(el)el.value=today;});
  document.querySelectorAll('.modal-ov').forEach(function(m){m.addEventListener('click',function(e){if(e.target===m)m.classList.remove('open');});});
  angFiltered=getAnggota(); akunFiltered=getAkunList();
  renderAll(); loadAbsDD(); loadSheetsConfig(); loadPengaturan(); updBadge();
}

function logout(){
  me=null; document.body.className='';
  document.getElementById('auth-screen').style.display='flex';
  document.getElementById('app').style.display='none';
  ['l-user','l-pass'].forEach(function(id){var el=document.getElementById(id);if(el)el.value='';});
  switchTab('login',null);
}

// ════════════════════════════════
// NAV
// ════════════════════════════════
var PM={dashboard:{t:'Dashboard',e:'🏠'},absensi:{t:'Absensi',e:'📋'},kas:{t:'Data Kas',e:'💰'},kegiatan:{t:'Kegiatan',e:'📅'},anggota:{t:'Daftar Anggota',e:'👥'},dokumen:{t:'Dokumen',e:'📄'},akun:{t:'Kelola Akun',e:'🔐'},pengaturan:{t:'Pengaturan',e:'⚙️'},sheets:{t:'Google Sheets',e:'📊'}};
function go(id,btn){
  document.querySelectorAll('.page').forEach(function(p){p.classList.remove('act');});
  document.querySelectorAll('.nav-btn').forEach(function(b){b.classList.remove('act');});
  var pg=document.getElementById('pg-'+id); if(pg)pg.classList.add('act');
  if(btn)btn.classList.add('act');
  var m=PM[id]||{t:id,e:'📄'};
  var pt=document.getElementById('pg-title'),pe=document.getElementById('pg-ico');
  if(pt)pt.textContent=m.t; if(pe)pe.textContent=m.e;
  if(id==='dashboard')renderDash();
  if(id==='dokumen')renderTpl();
  if(id==='akun')renderAkun();
  if(id==='pengaturan'){loadPengaturan();renderFB();renderFP();}
  tgSB();
}
function tgSB(){document.getElementById('sidebar').classList.toggle('open');}
function closeSB(){document.getElementById('sidebar').classList.remove('open');}
function openM(id){document.getElementById(id).classList.add('open');}
function closeM(id){document.getElementById(id).classList.remove('open');}

// ════════════════════════════════
// TOAST
// ════════════════════════════════
function toast(msg,type){
  type=type||'s';
  var el=document.getElementById('toast-el');
  el.innerHTML={s:'✅',e:'❌',i:'ℹ️'}[type]+'  '+msg;
  el.className='toast show '+type;
  setTimeout(function(){el.classList.remove('show');},3000);
}

// ════════════════════════════════
// FORMAT
// ════════════════════════════════
var fmt=function(n){return'Rp '+Number(n).toLocaleString('id-ID');};
var fD=function(s){if(!s)return'-';return new Date(s).toLocaleDateString('id-ID',{day:'numeric',month:'short',year:'numeric'});};
var AVCOL=['linear-gradient(135deg,#EF4444,#F97316)','linear-gradient(135deg,#3B82F6,#8B5CF6)','linear-gradient(135deg,#10B981,#3B82F6)','linear-gradient(135deg,#F59E0B,#EF4444)','linear-gradient(135deg,#8B5CF6,#EC4899)'];

function updBadge(){
  var pending=getAkunList().filter(function(a){return a.status==='pending';}).length;
  var nb=document.getElementById('nb-akun'); if(nb){nb.textContent=pending;nb.classList.toggle('hide',pending===0);}
  var banner=document.getElementById('banner-pending'),bc=document.getElementById('banner-cnt');
  if(banner)banner.classList.toggle('hide',pending===0||(me&&me.role!=='admin'));
  if(bc)bc.textContent=pending;
  var pendAng=getAnggota().filter(function(a){return a.status==='pending';}).length;
  var nba=document.getElementById('nb-ang'); if(nba){nba.textContent=pendAng;nba.classList.toggle('hide',pendAng===0);}
}

function renderAll(){renderDash();renderKas();renderKeg();renderAnggota();}

// ════════════════════════════════
// DASHBOARD
// ════════════════════════════════
function renderDash(){
  var aktif=getAnggota().filter(function(a){return a.status==='aktif';}).length;
  var st=document.getElementById('st-tot'); if(st)st.textContent=aktif;
  var last=S.history[0];
  var sh=document.getElementById('st-hdr'); if(sh)sh.textContent=last?last.hadir:'—';
  var saldo=S.kas.reduce(function(a,k){return k.jenis==='masuk'?a+k.jumlah:a-k.jumlah;},0);
  var sk=document.getElementById('st-kas'); if(sk)sk.textContent=fmt(saldo);
  var today=new Date().toISOString().split('T')[0];
  var skeg=document.getElementById('st-keg'); if(skeg)skeg.textContent=S.kegiatan.filter(function(k){return k.tgl>=today;}).length;
  var cb=document.getElementById('chartBars');
  if(cb){var days=['Sen','Sel','Rab','Kam','Jum','Sab','Min'],vals=[12,10,14,11,13,9,12],mx=Math.max.apply(null,vals);cb.innerHTML=days.map(function(d,i){return'<div class="ch-col"><div class="ch-bar" style="height:'+(vals[i]/mx*80)+'px;background:linear-gradient(180deg,var(--sky),rgba(59,130,246,.3))"></div><div class="ch-lbl">'+d+'</div></div>';}).join('');}
  var dk=document.getElementById('dash-keg');
  if(dk){var up=S.kegiatan.filter(function(k){return k.tgl>=today;}).sort(function(a,b){return new Date(a.tgl)-new Date(b.tgl);}).slice(0,3);dk.innerHTML=up.length?up.map(function(k){var d=new Date(k.tgl);return'<div class="keg-item" style="margin-bottom:8px"><div class="keg-dt"><div class="keg-day">'+d.getDate()+'</div><div class="keg-mon">'+d.toLocaleString('id-ID',{month:'short'})+'</div></div><div><div class="keg-title">'+k.nama+'</div><div class="keg-meta"><span>⏰'+k.waktu+'</span><span>📍'+k.lokasi+'</span></div></div></div>';}).join(''):'<div class="c3 fs-13 fw-7" style="text-align:center;padding:14px">Tidak ada kegiatan mendatang</div>';}
  var da=document.getElementById('dash-anggota');
  if(da){var rec=getAnggota().slice(0,5);da.innerHTML=rec.map(function(a){return'<tr><td class="fw-7">'+(a.nama||'-')+'</td><td class="c2">@'+a.username+'</td><td class="c2">'+fD(a.tgl)+'</td><td><span class="badge '+(a.status==='aktif'?'bg-green':a.status==='pending'?'bg-yellow':'bg-red')+'">'+a.status+'</span></td></tr>';}).join('');}
}

// ════════════════════════════════
// ABSENSI
// ════════════════════════════════
function loadAbsDD(){var sel=document.getElementById('abs-keg');if(!sel)return;sel.innerHTML='<option value="">-- Pilih Kegiatan --</option>'+S.kegiatan.map(function(k){return'<option value="'+k.id+'">'+k.nama+' ('+fD(k.tgl)+')</option>';}).join('');}
function loadAbs(){
  var id=(document.getElementById('abs-keg')||{}).value;
  var grid=document.getElementById('abs-grid'),empty=document.getElementById('abs-empty');
  if(!id){if(grid)grid.innerHTML='';if(empty)empty.style.display='block';return;}
  if(empty)empty.style.display='none';
  S.absensi=getAnggota().filter(function(a){return a.status==='aktif';}).map(function(a){return Object.assign({},a,{st:'hadir'});});
  var cnt=document.getElementById('abs-cnt'); if(cnt)cnt.textContent=S.absensi.length+' peserta';
  renderAbsGrid(); updAbsCnt();
}
function renderAbsGrid(){
  var isA=me&&me.role==='admin';
  var el=document.getElementById('abs-grid'); if(!el)return;
  el.innerHTML=S.absensi.map(function(a,i){
    var ini=((a.nama||a.username||'?').split(' ').map(function(n){return n[0];}).join('').slice(0,2)).toUpperCase();
    var ctrl=isA?'<div class="st-row"><button class="st-dot sh '+(a.st==='hadir'?'on':'')+'" onclick="setSt('+i+',\'hadir\')">✓</button><button class="st-dot sa '+(a.st==='alpha'?'on':'')+'" onclick="setSt('+i+',\'alpha\')">✗</button><button class="st-dot si '+(a.st==='izin'?'on':'')+'" onclick="setSt('+i+',\'izin\')">i</button></div>':'<span class="badge '+(a.st==='hadir'?'bg-green':a.st==='alpha'?'bg-red':'bg-yellow')+'">'+a.st+'</span>';
    return'<div class="abs-card '+a.st+'"><div class="abs-av" style="background:'+AVCOL[i%AVCOL.length]+'">'+ini+'</div><div class="abs-nm">'+(a.nama||a.username)+'</div>'+ctrl+'</div>';
  }).join('');
}
function setSt(i,s){S.absensi[i].st=s;renderAbsGrid();updAbsCnt();}
function setAllSt(s){if(!S.absensi.length){toast('Pilih kegiatan dulu','e');return;}S.absensi.forEach(function(a){a.st=s;});renderAbsGrid();updAbsCnt();}
function updAbsCnt(){
  var ah=document.getElementById('ah'),aa=document.getElementById('aa'),ai=document.getElementById('ai');
  if(ah)ah.textContent=S.absensi.filter(function(a){return a.st==='hadir';}).length;
  if(aa)aa.textContent=S.absensi.filter(function(a){return a.st==='alpha';}).length;
  if(ai)ai.textContent=S.absensi.filter(function(a){return a.st==='izin';}).length;
}
function saveAbs(){
  var id=(document.getElementById('abs-keg')||{}).value;
  if(!id||!S.absensi.length){toast('Pilih kegiatan dulu!','e');return;}
  var k=S.kegiatan.find(function(k){return k.id==id;});
  var rec={keg:k.nama,tgl:k.tgl,hadir:S.absensi.filter(function(a){return a.st==='hadir';}).length,alpha:S.absensi.filter(function(a){return a.st==='alpha';}).length,izin:S.absensi.filter(function(a){return a.st==='izin';}).length,total:S.absensi.length};
  S.history.unshift(rec);renderAbsHist();pushSheets('Absensi',[rec.keg,fD(rec.tgl),rec.hadir,rec.alpha,rec.izin,rec.total]);toast('Absensi disimpan! 🎉','s');
}
function renderAbsHist(){
  var tb=document.getElementById('abs-hist'),em=document.getElementById('abs-hist-empty');
  if(!S.history.length){if(em)em.style.display='block';if(tb)tb.innerHTML='';return;}
  if(em)em.style.display='none';
  if(tb)tb.innerHTML=S.history.map(function(h){return'<tr><td class="fw-7">'+h.keg+'</td><td class="c2">'+fD(h.tgl)+'</td><td><span class="badge bg-green">'+h.hadir+'</span></td><td><span class="badge bg-red">'+h.alpha+'</span></td><td><span class="badge bg-yellow">'+h.izin+'</span></td><td class="c2 fw-7">'+h.total+'</td></tr>';}).join('');
}

// ════════════════════════════════
// KAS
// ════════════════════════════════
function addKas(){
  var ket=((document.getElementById('k-ket')||{}).value||'').trim();
  var jml=Number((document.getElementById('k-jml')||{}).value||0);
  if(!ket||!jml){toast('Lengkapi semua field!','e');return;}
  var e={id:Date.now(),tgl:(document.getElementById('k-tgl')||{}).value,ket,kategori:(document.getElementById('k-kat')||{}).value,jenis:(document.getElementById('k-jenis')||{}).value,jumlah:jml};
  S.kas.unshift(e);renderKas();pushSheets('Kas',[e.tgl,e.ket,e.kategori,e.jenis,e.jumlah]);
  closeM('kas-modal');toast('Transaksi ditambahkan!','s');
  ['k-ket','k-jml'].forEach(function(id){var el=document.getElementById(id);if(el)el.value='';});
}
function renderKas(){
  var fl=S.kasFilter==='all'?S.kas:S.kas.filter(function(k){return k.jenis===S.kasFilter;});
  var tIn=S.kas.filter(function(k){return k.jenis==='masuk';}).reduce(function(a,k){return a+k.jumlah;},0);
  var tOut=S.kas.filter(function(k){return k.jenis==='keluar';}).reduce(function(a,k){return a+k.jumlah;},0);
  var es=document.getElementById('kas-saldo'),ei=document.getElementById('kas-in'),eo=document.getElementById('kas-out'),ec=document.getElementById('kas-cnt');
  if(es)es.textContent=fmt(tIn-tOut);if(ei)ei.textContent=fmt(tIn);if(eo)eo.textContent=fmt(tOut);if(ec)ec.textContent=S.kas.length;
  var tb=document.getElementById('kas-tbl'),em=document.getElementById('kas-empty');
  if(!fl.length){if(em)em.style.display='block';if(tb)tb.innerHTML='';return;}
  if(em)em.style.display='none';
  if(tb)tb.innerHTML=fl.map(function(k){return'<tr><td style="font-family:var(--mono);font-size:12px" class="c2">'+fD(k.tgl)+'</td><td class="fw-7">'+k.ket+'</td><td><span class="badge bg-gray">'+k.kategori+'</span></td><td><span class="badge '+(k.jenis==='masuk'?'bg-green':'bg-red')+'">'+(k.jenis==='masuk'?'⬆ Masuk':'⬇ Keluar')+'</span></td><td style="font-family:var(--mono);font-weight:800;color:'+(k.jenis==='masuk'?'var(--green)':'var(--red)')+'">'+( k.jenis==='masuk'?'+':'-')+fmt(k.jumlah)+'</td></tr>';}).join('');
}
function filterKas(t){
  S.kasFilter=t;
  ['all','masuk','keluar'].forEach(function(x){var b=document.getElementById('kf-'+x);if(b){b.style.borderColor=x===t?'var(--sky)':'';b.style.color=x===t?'var(--sky-d)':'';}}); renderKas();
}

// ════════════════════════════════
// KEGIATAN
// ════════════════════════════════
var TCLR={Pembelajaran:'bg-purple',Latihan:'bg-green',Rapat:'bg-yellow','Kegiatan Luar':'bg-red',Evaluasi:'bg-gray'};
function addKeg(){
  var nama=((document.getElementById('kg-nm')||{}).value||'').trim();
  var tgl=(document.getElementById('kg-tgl')||{}).value||'';
  if(!nama||!tgl){toast('Nama dan tanggal wajib!','e');return;}
  var e={id:Date.now(),nama,tgl,waktu:(document.getElementById('kg-wkt')||{}).value||'00:00',lokasi:(document.getElementById('kg-lok')||{}).value||'-',tipe:(document.getElementById('kg-tipe')||{}).value,desk:(document.getElementById('kg-desk')||{}).value||''};
  S.kegiatan.push(e);renderKeg();loadAbsDD();pushSheets('Kegiatan',[e.nama,e.tgl,e.waktu,e.lokasi,e.tipe]);
  closeM('keg-modal');toast('Kegiatan ditambahkan!','s');
  ['kg-nm','kg-desk','kg-lok'].forEach(function(id){var el=document.getElementById(id);if(el)el.value='';});
}
function renderKeg(){
  var today=new Date().toISOString().split('T')[0];
  var list=S.kegiatan.slice().sort(function(a,b){return new Date(a.tgl)-new Date(b.tgl);});
  if(S.kegFilter==='akan')list=list.filter(function(k){return k.tgl>=today;});
  if(S.kegFilter==='selesai')list=list.filter(function(k){return k.tgl<today;});
  var c=document.getElementById('keg-list'),em=document.getElementById('keg-empty');
  var isA=me&&me.role==='admin';
  if(!list.length){if(em)em.style.display='block';if(c)c.innerHTML='';return;}
  if(em)em.style.display='none';
  if(c)c.innerHTML=list.map(function(k){
    var d=new Date(k.tgl),lw=k.tgl<today;
    return'<div class="keg-item" style="opacity:'+(lw?.6:1)+'"><div class="keg-dt"><div class="keg-day">'+d.getDate()+'</div><div class="keg-mon">'+d.toLocaleString('id-ID',{month:'short'})+'</div></div><div class="flex-1"><div class="keg-title">'+k.nama+'</div><div class="keg-meta"><span>⏰'+k.waktu+'</span><span>📍'+k.lokasi+'</span><span class="badge '+(TCLR[k.tipe]||'bg-gray')+'">'+k.tipe+'</span><span class="badge '+(lw?'bg-gray':'bg-green')+'">'+(lw?'Selesai':'Mendatang')+'</span></div>'+(k.desk?'<div class="fs-12 c3 mt-8">'+k.desk+'</div>':'')+'</div>'+(isA?'<button class="btn btn-ghost btn-sm" onclick="delKeg('+k.id+')">🗑</button>':'')+'</div>';
  }).join('');
}
function filterKeg(t){S.kegFilter=t;renderKeg();}
function delKeg(id){if(!confirm('Hapus kegiatan?'))return;S.kegiatan=S.kegiatan.filter(function(k){return k.id!==id;});renderKeg();loadAbsDD();toast('Kegiatan dihapus','e');}

// ════════════════════════════════
// ANGGOTA
// ════════════════════════════════
function renderAnggota(list){
  var data=list||angFiltered;
  var ak=getAnggota().filter(function(a){return a.status==='aktif';}).length;
  var pe=getAnggota().filter(function(a){return a.status==='pending';}).length;
  var tot=getAnggota().length||1;
  var epak=document.getElementById('p-ak'),eppe=document.getElementById('p-pe');
  var pbak=document.getElementById('pb-ak'),pbpe=document.getElementById('pb-pe');
  if(epak)epak.textContent=ak;if(eppe)eppe.textContent=pe;
  if(pbak)pbak.style.width=(ak/tot*100)+'%';if(pbpe)pbpe.style.width=(pe/tot*100)+'%';
  var tb=document.getElementById('ang-tbl'),em=document.getElementById('ang-empty');
  var isA=me&&me.role==='admin';
  if(!data.length){if(em)em.style.display='block';if(tb)tb.innerHTML='';return;}
  if(em)em.style.display='none';
  if(tb)tb.innerHTML=data.map(function(a,i){
    return'<tr><td class="c3 fw-7">'+(i+1)+'</td><td class="fw-7">'+(a.nama||'-')+'</td><td class="c2">@'+a.username+'</td><td class="c2">'+(a.sekolah||'-')+'</td><td class="c2 fs-12">'+fD(a.tgl)+'</td><td><span class="badge '+(a.status==='aktif'?'bg-green':a.status==='pending'?'bg-yellow':'bg-red')+'">'+a.status+'</span></td><td class="admin-td">'+(isA?'<div class="flex gap-6">'+(a.status==='pending'?'<button class="btn btn-success btn-sm" onclick="verifA(\''+a.username+'\')">✓ Terima</button>':'')+'<button class="btn btn-ghost btn-sm" onclick="openEdit(\''+a.username+'\')">✏️</button><button class="btn btn-danger btn-sm" onclick="delA(\''+a.username+'\')">🗑</button></div>':'-')+'</td></tr>';
  }).join('');
}
function searchAng(q){var r=q.toLowerCase();angFiltered=getAnggota().filter(function(a){return(a.nama||'').toLowerCase().includes(r)||(a.username||'').toLowerCase().includes(r)||(a.sekolah||'').toLowerCase().includes(r);});renderAnggota(angFiltered);}
function filterAng(s){angFiltered=s==='all'?getAnggota():getAnggota().filter(function(a){return a.status===s;});renderAnggota(angFiltered);}
function verifA(u){var a=S.akun[u];if(!a)return;a.status='aktif';saveAkun();angFiltered=getAnggota();renderAnggota();renderAkun();updBadge();toast(a.nama+' diverifikasi! ✅','s');}
function delA(u){if(u==='admin'){toast('Akun admin tidak bisa dihapus','e');return;}if(!confirm('Hapus akun @'+u+'?'))return;delete S.akun[u];saveAkun();angFiltered=getAnggota();renderAnggota();renderAkun();updBadge();toast('Akun dihapus','e');}

// ════════════════════════════════
// KELOLA AKUN (Admin)
// ════════════════════════════════
function renderAkun(list){
  var data=list||getAkunList();
  var pending=data.filter(function(a){return a.status==='pending';});
  var pc=document.getElementById('pending-cnt'); if(pc)pc.textContent=pending.length+' akun';
  var plist=document.getElementById('akun-pending');
  if(plist)plist.innerHTML=pending.length?pending.map(function(a){
    return'<div class="akun-card"><div class="akun-av" style="background:'+AVCOL[0]+'">'+((a.nama||a.username||'?')[0]).toUpperCase()+'</div><div class="akun-info"><div class="akun-nm">'+(a.nama||a.username)+'</div><div class="akun-meta">@'+a.username+' · '+fD(a.tgl)+'</div><div class="akun-meta">'+(a.sekolah||'')+(a.kelas?' · '+a.kelas:'')+'</div></div><div class="flex gap-6"><button class="btn btn-success btn-sm" onclick="verifA(\''+a.username+'\')">✅ Terima</button><button class="btn btn-danger btn-sm" onclick="tolakA(\''+a.username+'\')">❌ Tolak</button></div></div>';
  }).join(''):'<div class="c3 fs-13 fw-7" style="text-align:center;padding:12px">Tidak ada akun pending 🎉</div>';
  var alist=document.getElementById('akun-all'),aem=document.getElementById('akun-empty');
  if(!data.length){if(aem)aem.style.display='block';if(alist)alist.innerHTML='';return;}
  if(aem)aem.style.display='none';
  if(alist)alist.innerHTML=data.map(function(a,i){
    return'<div class="akun-card"><div class="akun-av" style="background:'+AVCOL[i%AVCOL.length]+'">'+((a.nama||a.username||'?')[0]).toUpperCase()+'</div><div class="akun-info"><div class="akun-nm">'+(a.nama||a.username)+' <span class="badge '+(a.role==='admin'?'bg-blue':'bg-gray')+'">'+a.role+'</span></div><div class="akun-meta">@'+a.username+' · <span class="badge '+(a.status==='aktif'?'bg-green':a.status==='pending'?'bg-yellow':'bg-red')+'">'+a.status+'</span></div><div class="akun-meta">'+(a.sekolah||'')+(a.kelas?' · '+a.kelas:'')+(a.hp?' · '+a.hp:'')+'</div></div><div class="flex gap-6"><button class="btn btn-ghost btn-sm" onclick="openEdit(\''+a.username+'\')">✏️</button>'+(a.username!=='admin'?'<button class="btn btn-danger btn-sm" onclick="delA(\''+a.username+'\')">🗑</button>':'')+'</div></div>';
  }).join('');
}
function searchAkun(q){var r=q.toLowerCase();akunFiltered=getAkunList().filter(function(a){return(a.nama||'').toLowerCase().includes(r)||(a.username||'').toLowerCase().includes(r);});renderAkun(akunFiltered);}
function tolakA(u){if(!confirm('Tolak & hapus akun @'+u+'?'))return;delete S.akun[u];saveAkun();renderAkun();updBadge();toast('Akun ditolak','e');}
function addAkunManual(){
  var usr=((document.getElementById('am-usr')||{}).value||'').trim().toLowerCase();
  var pw=((document.getElementById('am-pw')||{}).value||'').trim();
  var nm=((document.getElementById('am-nm')||{}).value||'').trim();
  if(!usr||!pw||!nm){toast('Username, password & nama wajib!','e');return;}
  if(S.akun[usr]){toast('Username sudah ada','e');return;}
  S.akun[usr]={id:usr,username:usr,password:pw,nama:nm,role:(document.getElementById('am-role')||{}).value||'anggota',sekolah:(document.getElementById('am-skl')||{}).value||'',kelas:(document.getElementById('am-kls')||{}).value||'',hp:'',jk:'',email:'',tgl:new Date().toISOString().split('T')[0],status:'aktif'};
  saveAkun();renderAkun();angFiltered=getAnggota();renderAnggota();updBadge();
  closeM('akun-modal');toast('Akun @'+usr+' dibuat!','s');
  ['am-usr','am-pw','am-nm','am-skl','am-kls'].forEach(function(id){var el=document.getElementById(id);if(el)el.value='';});
}
function openEdit(u){
  var a=S.akun[u]; if(!a)return;
  var eid=document.getElementById('ea-id'),enm=document.getElementById('ea-nm'),epw=document.getElementById('ea-pw'),est=document.getElementById('ea-st'),erl=document.getElementById('ea-role');
  if(eid)eid.value=u;if(enm)enm.value=a.nama||'';if(epw)epw.value='';if(est)est.value=a.status||'aktif';if(erl)erl.value=a.role||'anggota';
  openM('edit-modal');
}
function saveEdit(){
  var u=(document.getElementById('ea-id')||{}).value||'';
  var a=S.akun[u]; if(!a)return;
  a.nama=(document.getElementById('ea-nm')||{}).value||a.nama;
  var np=((document.getElementById('ea-pw')||{}).value||'').trim(); if(np)a.password=np;
  a.status=(document.getElementById('ea-st')||{}).value||a.status;
  a.role=(document.getElementById('ea-role')||{}).value||a.role;
  saveAkun();renderAkun();angFiltered=getAnggota();renderAnggota();updBadge();
  closeM('edit-modal');toast('Akun @'+u+' diperbarui!','s');
}

// ════════════════════════════════
// PENGATURAN & FORM BUILDER
// ════════════════════════════════
function loadPengaturan(){
  var co=document.getElementById('cfg-org'),cp=document.getElementById('cfg-adm-pass');
  if(co)co.value=CFG.org; if(cp)cp.value=CFG.adminPass;
}
function saveGeneral(){
  var org=((document.getElementById('cfg-org')||{}).value||'').trim();
  var pw=((document.getElementById('cfg-adm-pass')||{}).value||'').trim();
  if(org){CFG.org=org;localStorage.setItem('ep_org',org);}
  if(pw){CFG.adminPass=pw;localStorage.setItem('ep_adm_pass',pw);}
  ['sb-org','auth-org'].forEach(function(id){var el=document.getElementById(id);if(el)el.textContent=CFG.org;});
  toast('Pengaturan disimpan!','s');
}
function renderFB(){
  var el=document.getElementById('field-builder'); if(!el)return;
  el.innerHTML=FC.map(function(f,i){
    var lock=f.locked?'style="opacity:.55;cursor:not-allowed"':'';
    return'<div class="fb-item" '+lock+'><span class="c3">⠿</span><div class="flex-1"><div class="fw-7 fs-13">'+f.label+'</div><div class="fs-11 c3">'+f.type+'</div></div>'+(f.locked?'<span class="fs-11 c3">Tetap</span>':'<button class="fb-req '+(f.required?'on':'off')+'" onclick="tgReq('+i+')">'+(f.required?'★ Wajib':'Opsional')+'</button><button class="fb-toggle '+(f.enabled?'on':'off')+'" onclick="tgField('+i+')" title="'+(f.enabled?'Aktif':'Nonaktif')+'"></button>')+'</div>';
  }).join('');
}
function tgField(i){if(!FC[i].locked){FC[i].enabled=!FC[i].enabled;renderFB();renderFP();}}
function tgReq(i){if(!FC[i].locked){FC[i].required=!FC[i].required;renderFB();renderFP();}}
function saveFieldCfg(){localStorage.setItem('ep_fc',JSON.stringify(FC));toast('Konfigurasi form pendaftaran disimpan!','s');}
function renderFP(){
  var el=document.getElementById('form-preview'); if(!el)return;
  var active=FC.filter(function(f){return f.enabled;});
  el.innerHTML=active.map(function(f){
    var req=f.required?'<span style="color:var(--red)">*</span>':'';
    var inp='';
    if(f.type==='select')inp='<select class="inp" disabled>'+(f.opts||['Pilihan']).map(function(o){return'<option>'+o+'</option>';}).join('')+'</select>';
    else if(f.type==='textarea')inp='<textarea class="inp" rows="2" disabled placeholder="'+f.label+'"></textarea>';
    else inp='<input class="inp" type="'+f.type+'" disabled placeholder="'+f.label+'">';
    return'<div class="fg"><label class="lbl">'+f.label+' '+req+'</label>'+inp+'</div>';
  }).join('');
}

// ════════════════════════════════
// DOKUMEN
// ════════════════════════════════
var TPLICO={surat:'📝',undangan:'💌',berita:'📰',absensi:'📋',lain:'📄'};
var TPLCLR={surat:'ic-blue',undangan:'ic-purple',berita:'ic-green',absensi:'ic-yellow',lain:'ic-red'};
function uploadTpl(){
  var nm=((document.getElementById('tpl-nama')||{}).value||'').trim();
  var isi=((document.getElementById('tpl-isi')||{}).value||'').trim();
  if(!nm||!isi){toast('Nama dan isi template wajib!','e');return;}
  var e={id:Date.now(),nama:nm,tipe:(document.getElementById('tpl-tipe')||{}).value,desc:(document.getElementById('tpl-desc')||{}).value||'',isi,by:me?me.nama||me.username:'Admin',tgl:new Date().toISOString().split('T')[0]};
  S.templates.unshift(e);renderTpl();toast('Template diupload!','s');
  ['tpl-nama','tpl-desc','tpl-isi'].forEach(function(id){var el=document.getElementById(id);if(el)el.value='';});
}
function renderTpl(filter){
  filter=filter||'all';
  var list=filter==='all'?S.templates:S.templates.filter(function(t){return t.tipe===filter;});
  var el=document.getElementById('tpl-list'); if(!el)return;
  var isA=me&&me.role==='admin';
  if(!list.length){el.innerHTML='<div class="c3 fs-13 fw-7" style="text-align:center;padding:24px">Belum ada template untuk tipe ini</div>';return;}
  el.innerHTML=list.map(function(t){
    return'<div class="doc-card"><div class="doc-ico '+(TPLCLR[t.tipe]||'ic-blue')+'">'+(TPLICO[t.tipe]||'📄')+'</div><div class="doc-info"><div class="doc-title">'+t.nama+'</div><div class="doc-meta">Oleh '+t.by+' · '+fD(t.tgl)+'</div>'+(t.desc?'<div class="fs-12 c3 mt-8">'+t.desc+'</div>':'')+'</div><div class="flex gap-6"><button class="btn btn-primary btn-sm" onclick="openDocForm('+t.id+')">📝 Buat</button>'+(isA?'<button class="btn btn-ghost btn-sm" onclick="delTpl('+t.id+')">🗑</button>':'')+'</div></div>';
  }).join('');
}
function filterTpl(v){renderTpl(v);}
function openDocForm(tplId){
  var tpl=S.templates.find(function(t){return t.id===tplId;}); if(!tpl)return;
  S.curTpl=tpl;
  var vars=[...new Set([...tpl.isi.matchAll(/\{\{(\w+)\}\}/g)].map(function(m){return m[1];}))];
  var LABELS={NAMA:'Nama Lengkap',TANGGAL:'Tanggal',ORGANISASI:'Nama Organisasi',JABATAN:'Jabatan',KEPERLUAN:'Keperluan/Agenda',LOKASI:'Lokasi',KOTA:'Kota'};
  var df=document.getElementById('doc-fields');
  if(df)df.innerHTML=vars.map(function(v){
    var def=v==='ORGANISASI'?CFG.org:v==='TANGGAL'?new Date().toLocaleDateString('id-ID'):v==='NAMA'?(me&&(me.nama||me.username)||''):'';
    return'<div class="fg"><label class="lbl">'+(LABELS[v]||v)+'</label><input class="inp" id="dv-'+v+'" placeholder="Isi '+(LABELS[v]||v)+'..." oninput="updPrev()" value="'+def+'"></div>';
  }).join('');
  updPrev(); openM('doc-modal');
}
function updPrev(){
  if(!S.curTpl)return;
  var text=S.curTpl.isi;
  var vars=[...new Set([...text.matchAll(/\{\{(\w+)\}\}/g)].map(function(m){return m[1];}))];
  vars.forEach(function(v){var el=document.getElementById('dv-'+v);var val=el?el.value||('['+v+']'):'['+v+']';text=text.split('{{'+v+'}}').join(val);});
  var dp=document.getElementById('doc-preview'); if(dp)dp.textContent=text;
}
function printDoc(){
  var txt=(document.getElementById('doc-preview')||{}).textContent||'';
  var w=window.open('','_blank');
  w.document.write('<!DOCTYPE html><html><head><title>'+(S.curTpl&&S.curTpl.nama||'Dokumen')+'</title><style>body{font-family:Arial,sans-serif;padding:40px;white-space:pre-wrap;font-size:13px;line-height:1.8}@media print{button{display:none}}</style></head><body><button onclick="window.print()" style="margin-bottom:20px;padding:8px 16px;background:#3B82F6;color:#fff;border:none;border-radius:6px;cursor:pointer;font-weight:700">🖨️ Print / PDF</button><div>'+txt+'</div></body></html>');
  w.document.close();
}
function downloadDoc(){
  var txt=(document.getElementById('doc-preview')||{}).textContent||'';
  if(!txt.trim()){toast('Preview kosong','e');return;}
  var nm=S.curTpl&&S.curTpl.nama||'dokumen';
  var blob=new Blob([txt],{type:'text/plain;charset=utf-8'});
  var a=document.createElement('a');a.href=URL.createObjectURL(blob);a.download=nm.replace(/\s+/g,'_')+'.txt';a.click();
  S.docHistory.unshift({judul:nm,tpl:nm,oleh:me?me.nama||me.username:'—',tgl:new Date().toISOString().split('T')[0],txt});
  renderDocHist();closeM('doc-modal');toast('Dokumen diunduh!','s');
}
function renderDocHist(){
  var tb=document.getElementById('doc-hist-tbl'),em=document.getElementById('doc-hist-empty');
  if(!S.docHistory.length){if(em)em.style.display='block';if(tb)tb.innerHTML='';return;}
  if(em)em.style.display='none';
  if(tb)tb.innerHTML=S.docHistory.map(function(d,i){
    return'<tr><td class="fw-7">'+d.judul+'</td><td class="c2">'+d.tpl+'</td><td class="c2">'+d.oleh+'</td><td class="c2 fs-12">'+fD(d.tgl)+'</td><td><button class="btn btn-ghost btn-sm" onclick="redown('+i+')">📥</button></td></tr>';
  }).join('');
}
function redown(i){var d=S.docHistory[i];var blob=new Blob([d.txt],{type:'text/plain;charset=utf-8'});var a=document.createElement('a');a.href=URL.createObjectURL(blob);a.download=d.judul.replace(/\s+/g,'_')+'.txt';a.click();toast('Diunduh ulang','s');}
function delTpl(id){if(!confirm('Hapus template?'))return;S.templates=S.templates.filter(function(t){return t.id!==id;});renderTpl();toast('Template dihapus','e');}

// ════════════════════════════════
// EXPORT
// ════════════════════════════════
function xlsxReady(cb){
  if(window.XLSX){cb();return;}
  var s=document.createElement('script');s.src='https://cdnjs.cloudflare.com/ajax/libs/xlsx/0.18.5/xlsx.full.min.js';
  s.onload=cb;s.onerror=function(){toast('Gagal muat library Excel','e');};document.head.appendChild(s);
}
function xlsxExport(hdrs,rows,sheet,file){xlsxReady(function(){var ws=XLSX.utils.aoa_to_sheet([hdrs].concat(rows));ws['!cols']=hdrs.map(function(){return{wch:20};});var wb=XLSX.utils.book_new();XLSX.utils.book_append_sheet(wb,ws,sheet);XLSX.writeFile(wb,file);toast('Excel diunduh!','s');});}
function doXLSX(type){
  if(type==='anggota')xlsxExport(['No','Nama','Username','Sekolah','Kelas','HP','JK','Tgl Daftar','Status'],getAnggota().map(function(a,i){return[i+1,a.nama,a.username,a.sekolah,a.kelas,a.hp,a.jk,fD(a.tgl),a.status];}),'Anggota','Data_Anggota.xlsx');
  if(type==='kas')xlsxExport(['Tanggal','Keterangan','Kategori','Jenis','Jumlah'],S.kas.map(function(k){return[fD(k.tgl),k.ket,k.kategori,k.jenis==='masuk'?'Pemasukan':'Pengeluaran',k.jumlah];}),'Kas','Data_Kas.xlsx');
  if(type==='kegiatan')xlsxExport(['Nama','Tanggal','Waktu','Lokasi','Tipe','Deskripsi'],S.kegiatan.map(function(k){return[k.nama,fD(k.tgl),k.waktu,k.lokasi,k.tipe,k.desk];}),'Kegiatan','Data_Kegiatan.xlsx');
  if(type==='absensi'){if(!S.absensi.length){toast('Muat absensi dulu','e');return;}xlsxExport(['No','Nama','Status'],S.absensi.map(function(a,i){return[i+1,a.nama||a.username,a.st];}),'Absensi','Absensi.xlsx');}
  if(type==='histori'){if(!S.history.length){toast('Belum ada riwayat','e');return;}xlsxExport(['Kegiatan','Tanggal','Hadir','Alpha','Izin','Total'],S.history.map(function(h){return[h.keg,fD(h.tgl),h.hadir,h.alpha,h.izin,h.total];}),'Riwayat','Riwayat_Absensi.xlsx');}
}
function doPDF(type){
  var html='',title='';
  if(type==='kas'){var tIn=S.kas.filter(function(k){return k.jenis==='masuk';}).reduce(function(a,k){return a+k.jumlah;},0),tOut=S.kas.filter(function(k){return k.jenis==='keluar';}).reduce(function(a,k){return a+k.jumlah;},0);title='Laporan Kas';html='<h2>💰 Laporan Kas</h2><p>Dicetak: '+new Date().toLocaleDateString('id-ID')+'</p><p><b>Saldo:</b> '+fmt(tIn-tOut)+'</p><table><tr><th>Tanggal</th><th>Keterangan</th><th>Kategori</th><th>Jenis</th><th>Jumlah</th></tr>'+S.kas.map(function(k){return'<tr><td>'+fD(k.tgl)+'</td><td>'+k.ket+'</td><td>'+k.kategori+'</td><td>'+(k.jenis==='masuk'?'Masuk':'Keluar')+'</td><td>'+fmt(k.jumlah)+'</td></tr>';}).join('')+'</table>';}
  if(type==='absensi'){if(!S.absensi.length){toast('Muat absensi dulu','e');return;}var nm=(document.getElementById('abs-keg')||{}).selectedOptions;nm=nm&&nm[0]?nm[0].text:'Absensi';title='Absensi';html='<h2>📋 Absensi</h2><p><b>Kegiatan:</b> '+nm+'</p><table><tr><th>#</th><th>Nama</th><th>Status</th></tr>'+S.absensi.map(function(a,i){return'<tr><td>'+(i+1)+'</td><td>'+(a.nama||a.username)+'</td><td>'+a.st.toUpperCase()+'</td></tr>';}).join('')+'</table>';}
  if(!html)return;
  var w=window.open('','_blank');
  w.document.write('<!DOCTYPE html><html><head><title>'+title+'</title><style>body{font-family:Arial,sans-serif;padding:24px;font-size:13px}table{width:100%;border-collapse:collapse;margin-top:12px}th,td{border:1px solid #ddd;padding:7px}th{background:#f0f0f0}@media print{button{display:none}}</style></head><body><button onclick="window.print()" style="margin-bottom:14px;padding:8px 16px;background:#3B82F6;color:#fff;border:none;border-radius:6px;cursor:pointer;font-weight:700">🖨️ Print/PDF</button>'+html+'</body></html>');
  w.document.close();
}

// ════════════════════════════════
// GOOGLE SHEETS
// ════════════════════════════════
function loadSheetsConfig(){
  var url=localStorage.getItem('ep_sheets_url')||'',id=localStorage.getItem('ep_sheets_id')||'';
  CFG.sheetsUrl=url;
  var cu=document.getElementById('cfg-url'),ci=document.getElementById('cfg-sid');
  if(cu)cu.value=url; if(ci)ci.value=id;
  updSDot(!!url);
}
function saveSheets(){
  var url=((document.getElementById('cfg-url')||{}).value||'').trim();
  var id=((document.getElementById('cfg-sid')||{}).value||'').trim();
  CFG.sheetsUrl=url;localStorage.setItem('ep_sheets_url',url);localStorage.setItem('ep_sheets_id',id);
  updSDot(!!url);toast('Konfigurasi Sheets disimpan!','s');
}
function updSDot(ok){var d=document.getElementById('sdot'),l=document.getElementById('slbl');if(d)d.className='sdot'+(ok?' ok':'');if(l)l.textContent=ok?'Sheets: On':'Sheets: Off';}
function addLog(msg){var el=document.getElementById('slog');if(!el)return;var t=new Date().toLocaleTimeString('id-ID');el.innerHTML='['+t+'] '+msg+'<br>'+el.innerHTML;}
function testConn(){if(!CFG.sheetsUrl){toast('Masukkan URL dulu!','e');return;}addLog('🔄 Testing...');fetch(CFG.sheetsUrl+'?action=ping').then(function(r){return r.json();}).then(function(){updSDot(true);addLog('✅ Koneksi berhasil!');toast('Koneksi berhasil!','s');}).catch(function(){addLog('⚠️ Gagal. Cek URL & permission.');toast('Koneksi gagal','e');});}
function pushSheets(sheet,row){if(!CFG.sheetsUrl)return;fetch(CFG.sheetsUrl,{method:'POST',mode:'no-cors',body:JSON.stringify({sheet,row})}).then(function(){addLog('✅ '+sheet+' synced');}).catch(function(){addLog('⚠️ '+sheet+' gagal sync');});}
function syncAll(){if(!CFG.sheetsUrl){toast('Simpan config dulu!','e');return;}addLog('☁️ Sync semua...');fetch(CFG.sheetsUrl,{method:'POST',mode:'no-cors',body:JSON.stringify({action:'syncAll',akun:getAkunList(),kas:S.kas,kegiatan:S.kegiatan,history:S.history})}).then(function(){addLog('✅ Sync selesai!');toast('Sync selesai!','s');}).catch(function(){addLog('⚠️ Sync gagal.');toast('Sync gagal','e');});}
function copyScript(){
  var code='function doPost(e){try{var d=JSON.parse(e.postData.contents);var ss=SpreadsheetApp.getActiveSpreadsheet();if(d.action===\'syncAll\'){wr(ss,\'Akun\',[\'Nama\',\'Username\',\'Role\',\'Sekolah\',\'Tgl\',\'Status\'],d.akun.map(function(a){return[a.nama,a.username,a.role,a.sekolah,a.tgl,a.status];}));wr(ss,\'Kas\',[\'Tgl\',\'Ket\',\'Kategori\',\'Jenis\',\'Jumlah\'],d.kas.map(function(k){return[k.tgl,k.ket,k.kategori,k.jenis,k.jumlah];}));wr(ss,\'Kegiatan\',[\'Nama\',\'Tgl\',\'Waktu\',\'Lokasi\',\'Tipe\'],d.kegiatan.map(function(k){return[k.nama,k.tgl,k.waktu,k.lokasi,k.tipe];}));wr(ss,\'Absensi\',[\'Keg\',\'Tgl\',\'Hadir\',\'Alpha\',\'Izin\',\'Total\'],d.history.map(function(h){return[h.keg,h.tgl,h.hadir,h.alpha,h.izin,h.total];}));return out({status:\'synced\'});}var sh=ss.getSheetByName(d.sheet)||ss.insertSheet(d.sheet);sh.appendRow(d.row);return out({status:\'ok\'});}catch(err){return out({error:err.message});}}\nfunction doGet(e){return out({status:e.parameter.action===\'ping\'?\'ok\':\'ready\'});}\nfunction wr(ss,n,h,rows){var s=ss.getSheetByName(n);if(!s)s=ss.insertSheet(n);s.clearContents();s.getRange(1,1,1,h.length).setValues([h]);if(rows.length)s.getRange(2,1,rows.length,h.length).setValues(rows);}\nfunction out(o){return ContentService.createTextOutput(JSON.stringify(o)).setMimeType(ContentService.MimeType.JSON);}';
  navigator.clipboard.writeText(code).then(function(){toast('Kode Apps Script disalin!','i');}).catch(function(){toast('Gagal menyalin','e');});
}

/* ── WordPress Integration ── */
(function(){
  'use strict';
  function applyWP(){
    if(!window.EP_WP_MODE) return;
    if(window.EP_ADMIN_PASS   && typeof CFG!=='undefined') CFG.adminPass   = window.EP_ADMIN_PASS;
    if(window.EP_ANGGOTA_PASS && typeof S!=='undefined' && S.akun && S.akun.anggota) S.akun.anggota.password = window.EP_ANGGOTA_PASS;
    if(window.EP_ORG && typeof CFG!=='undefined'){
      CFG.org=window.EP_ORG;
      ['sb-org','auth-org'].forEach(function(id){var el=document.getElementById(id);if(el)el.textContent=window.EP_ORG;});
    }
    if(window.EP_SHEETS_URL && typeof CFG!=='undefined') CFG.sheetsUrl = window.EP_SHEETS_URL;
  }
  if(document.readyState==='loading') document.addEventListener('DOMContentLoaded', applyWP);
  else applyWP();
})();
