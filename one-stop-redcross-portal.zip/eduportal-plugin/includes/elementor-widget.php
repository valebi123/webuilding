<?php
if (!defined('ABSPATH')) exit;
class EduPortal_Elementor_Widget extends \Elementor\Widget_Base {
    public function get_name()  { return 'eduportal_widget'; }
    public function get_title() { return 'EduPortal'; }
    public function get_icon()  { return 'eicon-user-circle-o'; }
    public function get_categories() { return ['general']; }
    protected function _register_controls() {
        $this->start_controls_section('content', ['label'=>'EduPortal','tab'=>\Elementor\Controls_Manager::TAB_CONTENT]);
        $this->add_control('mode', ['label'=>'Mode','type'=>\Elementor\Controls_Manager::SELECT,'default'=>'full',
            'options'=>['full'=>'Portal Lengkap','daftar'=>'Form Pendaftaran','kegiatan'=>'Jadwal Kegiatan']]);
        $this->end_controls_section();
    }
    protected function render() {
        $s = $this->get_settings_for_display();
        $map = ['full'=>'[eduportal]','daftar'=>'[eduportal_daftar]','kegiatan'=>'[eduportal_kegiatan]'];
        echo do_shortcode($map[$s['mode']] ?? '[eduportal]');
    }
}
