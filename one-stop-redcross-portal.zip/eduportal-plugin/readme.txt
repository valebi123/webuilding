=== One-Stop Red Cross Portal ===
Plugin Name:  One-Stop Red Cross Portal
Version:      5.0.0
Requires at least: 5.8
Tested up to: 6.5
Requires PHP: 7.4
License:      GPLv2
Author:       Lenvalen

Kreasi Tanpa Batas untuk PMI, oleh Lenvalen.

Portal manajemen lengkap untuk organisasi PMR/PMI:
absensi, kas, kegiatan, pendaftaran mandiri anggota,
kelola akun, form builder, modul dokumen & Google Sheets sync.

== Fitur Utama ==
* Registrasi akun mandiri (anggota daftar sendiri)
* Admin verifikasi akun baru (terima/tolak)
* Form builder — atur field pendaftaran sesuka hati
* Login role-based (Admin & Anggota)
* Absensi per kegiatan + riwayat + export Excel & PDF
* Data kas (pemasukan & pengeluaran)
* Jadwal kegiatan + filter
* Modul Dokumen: upload template variabel, buat & download
* Kelola akun: tambah manual, edit, nonaktifkan
* Sinkronisasi Google Sheets
* Kompatibel Astra & Elementor

== Shortcodes ==
[eduportal]           Portal lengkap
[eduportal_daftar]    Form pendaftaran publik
[eduportal_kegiatan]  Jadwal kegiatan publik

== Installation ==
1. Plugins > Add New > Upload Plugin > pilih ZIP > Install > Activate
2. Menu One-Stop Red Cross Portal > Pengaturan
3. Buat halaman baru > blok Shortcode > [eduportal] > Publish
4. Astra: Page Settings > Full Width, No Sidebar

== Credits ==
Dibuat oleh Lenvalen — Kreasi Tanpa Batas untuk PMI.

== Changelog ==
= 5.0.0 =
* Rebranding ke One-Stop Red Cross Portal by Lenvalen
* Fitur registrasi akun mandiri (3-step dengan form builder)
* Admin form builder — konfigurasi field daftar dari UI
* Kelola akun dengan verifikasi, edit, tolak
* Perbaikan bug layar putih & JSON response error
