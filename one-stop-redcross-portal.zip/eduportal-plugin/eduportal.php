<?php
/**
 * Plugin Name: One-Stop Red Cross Portal
 * Plugin URI:  https://fasilitatorkotablitar.my.id
 * Description: Portal manajemen absensi, kas, kegiatan, pendaftaran peserta & dokumen. Kompatibel Astra & Elementor.
 * Version:     4.1.0
 * Author:      EduPortal
 * License:     GPL2
 * Text Domain: eduportal
 */

if ( ! defined( 'ABSPATH' ) ) exit;

define( 'EDUPORTAL_VERSION', '4.1.0' );
define( 'EDUPORTAL_DIR',     plugin_dir_path( __FILE__ ) );
define( 'EDUPORTAL_URL',     plugin_dir_url( __FILE__ ) );

/* ============================================================
   HELPER — get daftar page url safely
   ============================================================ */
function eduportal_daftar_url() {
    $page = get_page_by_path( 'daftar' );
    if ( $page && isset( $page->ID ) ) {
        return get_permalink( $page->ID );
    }
    return home_url( '/daftar' );
}

/* ============================================================
   ENQUEUE ASSETS
   ============================================================ */
add_action( 'wp_enqueue_scripts', 'eduportal_enqueue' );
function eduportal_enqueue() {
    global $post;
    if ( ! is_a( $post, 'WP_Post' ) ) return;

    $shortcodes = array( 'eduportal', 'eduportal_daftar', 'eduportal_kegiatan' );
    $found = false;
    foreach ( $shortcodes as $sc ) {
        if ( has_shortcode( $post->post_content, $sc ) ) {
            $found = true;
            break;
        }
    }
    if ( ! $found ) return;

    wp_enqueue_style(
        'eduportal-style',
        EDUPORTAL_URL . 'assets/css/eduportal.css',
        array(),
        EDUPORTAL_VERSION
    );

    wp_enqueue_script(
        'eduportal-app',
        EDUPORTAL_URL . 'assets/js/eduportal-app.js',
        array(),
        EDUPORTAL_VERSION,
        true
    );

    // Semua data config dikirim via wp_localize_script (aman, tidak ada constant)
    $config = array(
        'ajaxUrl'     => admin_url( 'admin-ajax.php' ),
        'nonce'       => wp_create_nonce( 'eduportal_nonce' ),
        'pluginUrl'   => EDUPORTAL_URL,
        'orgName'     => get_option( 'eduportal_org_name', get_bloginfo( 'name' ) ),
        'adminPass'   => get_option( 'eduportal_admin_pass', 'admin123' ),
        'anggotaPass' => get_option( 'eduportal_anggota_pass', 'anggota123' ),
        'sheetsUrl'   => get_option( 'eduportal_sheets_url', '' ),
        'sheetsId'    => get_option( 'eduportal_sheets_id', '' ),
        'daftarUrl'   => eduportal_daftar_url(),
    );

    wp_localize_script( 'eduportal-app', 'EDUPORTAL_WP', $config );
}

/* ============================================================
   SHORTCODES
   ============================================================ */
add_shortcode( 'eduportal',          'eduportal_sc_full' );
add_shortcode( 'eduportal_daftar',   'eduportal_sc_daftar' );
add_shortcode( 'eduportal_kegiatan', 'eduportal_sc_kegiatan' );

function eduportal_sc_full( $atts ) {
    ob_start();
    include EDUPORTAL_DIR . 'templates/portal-full.php';
    return ob_get_clean();
}
function eduportal_sc_daftar( $atts ) {
    ob_start();
    include EDUPORTAL_DIR . 'templates/form-daftar.php';
    return ob_get_clean();
}
function eduportal_sc_kegiatan( $atts ) {
    ob_start();
    include EDUPORTAL_DIR . 'templates/kegiatan-publik.php';
    return ob_get_clean();
}

/* ============================================================
   DATABASE INSTALL
   ============================================================ */
register_activation_hook( __FILE__, 'eduportal_install' );
function eduportal_install() {
    global $wpdb;
    $charset = $wpdb->get_charset_collate();
    require_once ABSPATH . 'wp-admin/includes/upgrade.php';

    dbDelta( "CREATE TABLE {$wpdb->prefix}eduportal_peserta (
        id      INT AUTO_INCREMENT PRIMARY KEY,
        nama    VARCHAR(200) NOT NULL,
        sekolah VARCHAR(200) NOT NULL,
        kelas   VARCHAR(50),
        hp      VARCHAR(20),
        jk      VARCHAR(20),
        email   VARCHAR(100),
        alamat  TEXT,
        tgl     DATE,
        status  VARCHAR(20) DEFAULT 'pending'
    ) $charset;" );

    dbDelta( "CREATE TABLE {$wpdb->prefix}eduportal_kas (
        id       INT AUTO_INCREMENT PRIMARY KEY,
        tgl      DATE NOT NULL,
        ket      VARCHAR(255) NOT NULL,
        kategori VARCHAR(100),
        jenis    VARCHAR(20) NOT NULL,
        jumlah   DECIMAL(15,2) NOT NULL
    ) $charset;" );

    dbDelta( "CREATE TABLE {$wpdb->prefix}eduportal_kegiatan (
        id     INT AUTO_INCREMENT PRIMARY KEY,
        nama   VARCHAR(200) NOT NULL,
        tgl    DATE NOT NULL,
        waktu  VARCHAR(10),
        lokasi VARCHAR(200),
        tipe   VARCHAR(50),
        desk   TEXT
    ) $charset;" );

    dbDelta( "CREATE TABLE {$wpdb->prefix}eduportal_absensi (
        id          INT AUTO_INCREMENT PRIMARY KEY,
        kegiatan_id INT NOT NULL,
        peserta_id  INT NOT NULL,
        status      VARCHAR(20) NOT NULL,
        created_at  DATETIME DEFAULT CURRENT_TIMESTAMP
    ) $charset;" );

    dbDelta( "CREATE TABLE {$wpdb->prefix}eduportal_templates (
        id          INT AUTO_INCREMENT PRIMARY KEY,
        nama        VARCHAR(200) NOT NULL,
        tipe        VARCHAR(50),
        desk        TEXT,
        isi         LONGTEXT NOT NULL,
        uploaded_by VARCHAR(100),
        created_at  DATETIME DEFAULT CURRENT_TIMESTAMP
    ) $charset;" );

    dbDelta( "CREATE TABLE {$wpdb->prefix}eduportal_dokumen (
        id          INT AUTO_INCREMENT PRIMARY KEY,
        judul       VARCHAR(200) NOT NULL,
        template_id INT,
        dibuat_oleh VARCHAR(100),
        konten      LONGTEXT,
        created_at  DATETIME DEFAULT CURRENT_TIMESTAMP
    ) $charset;" );

    // Seed data contoh
    $count = $wpdb->get_var( "SELECT COUNT(*) FROM {$wpdb->prefix}eduportal_kegiatan" );
    if ( $count == 0 ) {
        $wpdb->insert( "{$wpdb->prefix}eduportal_kegiatan", array(
            'nama'   => 'Latihan Dasar PMR',
            'tgl'    => date( 'Y-m-d', strtotime( '+7 days' ) ),
            'waktu'  => '08:00',
            'lokasi' => 'Aula Sekolah',
            'tipe'   => 'Latihan',
            'desk'   => 'Latihan dasar pertolongan pertama untuk anggota baru',
        ) );
    }

    $tc = $wpdb->get_var( "SELECT COUNT(*) FROM {$wpdb->prefix}eduportal_templates" );
    if ( $tc == 0 ) {
        $wpdb->insert( "{$wpdb->prefix}eduportal_templates", array(
            'nama'        => 'Surat Keterangan Aktif',
            'tipe'        => 'surat',
            'desk'        => 'Surat keterangan anggota aktif organisasi',
            'isi'         => "SURAT KETERANGAN AKTIF\n\nYang bertanda tangan di bawah ini menerangkan bahwa:\n\nNama         : {{NAMA}}\nJabatan      : {{JABATAN}}\nOrganisasi   : {{ORGANISASI}}\n\nAdalah benar merupakan anggota aktif {{ORGANISASI}}.\nSurat ini dibuat untuk keperluan {{KEPERLUAN}}.\n\nDemikian surat keterangan ini dibuat dengan sebenarnya.\n\n{{KOTA}}, {{TANGGAL}}\n\n\nKetua {{ORGANISASI}}",
            'uploaded_by' => 'Admin',
        ) );
        $wpdb->insert( "{$wpdb->prefix}eduportal_templates", array(
            'nama'        => 'Surat Undangan Kegiatan',
            'tipe'        => 'undangan',
            'desk'        => 'Template undangan untuk kegiatan resmi',
            'isi'         => "SURAT UNDANGAN\n\nKepada Yth.\nSdr/i {{NAMA}}\ndi Tempat\n\nDengan hormat,\nBersama surat ini, kami {{ORGANISASI}} mengundang Anda untuk hadir dalam:\n\nKegiatan : {{KEPERLUAN}}\nTanggal  : {{TANGGAL}}\nLokasi   : {{LOKASI}}\n\nAtas perhatian dan kehadiran Anda, kami ucapkan terima kasih.\n\nHormat kami,\n{{ORGANISASI}}",
            'uploaded_by' => 'Admin',
        ) );
        $wpdb->insert( "{$wpdb->prefix}eduportal_templates", array(
            'nama'        => 'Berita Acara Rapat',
            'tipe'        => 'berita',
            'desk'        => 'Template berita acara rapat organisasi',
            'isi'         => "BERITA ACARA RAPAT\n\nPada hari ini, {{TANGGAL}},\ntelah dilaksanakan rapat {{ORGANISASI}} dengan:\n\nAgenda   : {{KEPERLUAN}}\nPemimpin : {{NAMA}}\nJabatan  : {{JABATAN}}\nTempat   : {{LOKASI}}\n\nRapat berjalan dengan lancar.\n\nDisetujui oleh,\n\n\n{{NAMA}}\n{{JABATAN}}",
            'uploaded_by' => 'Admin',
        ) );
    }

    update_option( 'eduportal_db_version', '4.1.0' );
}

register_deactivation_hook( __FILE__, function() { flush_rewrite_rules(); } );

/* ============================================================
   AJAX — Load data
   ============================================================ */
add_action( 'wp_ajax_eduportal_load_data', 'eduportal_ajax_load' );
function eduportal_ajax_load() {
    // Wajib: matikan output apapun sebelum JSON
    if ( ob_get_length() ) ob_clean();

    check_ajax_referer( 'eduportal_nonce', 'nonce' );
    global $wpdb;

    $data = array(
        'peserta'   => $wpdb->get_results( "SELECT * FROM {$wpdb->prefix}eduportal_peserta ORDER BY tgl DESC", ARRAY_A ),
        'kas'       => $wpdb->get_results( "SELECT * FROM {$wpdb->prefix}eduportal_kas ORDER BY tgl DESC", ARRAY_A ),
        'kegiatan'  => $wpdb->get_results( "SELECT * FROM {$wpdb->prefix}eduportal_kegiatan ORDER BY tgl DESC", ARRAY_A ),
        'templates' => $wpdb->get_results( "SELECT * FROM {$wpdb->prefix}eduportal_templates ORDER BY created_at DESC", ARRAY_A ),
        'dokumen'   => $wpdb->get_results( "SELECT * FROM {$wpdb->prefix}eduportal_dokumen ORDER BY created_at DESC LIMIT 50", ARRAY_A ),
        'absensi'   => $wpdb->get_results( "SELECT * FROM {$wpdb->prefix}eduportal_absensi ORDER BY created_at DESC LIMIT 200", ARRAY_A ),
    );

    wp_send_json_success( $data );
}

/* ============================================================
   AJAX — Daftar peserta (publik)
   ============================================================ */
add_action( 'wp_ajax_nopriv_eduportal_daftar', 'eduportal_ajax_daftar' );
add_action( 'wp_ajax_eduportal_daftar',        'eduportal_ajax_daftar' );
function eduportal_ajax_daftar() {
    if ( ob_get_length() ) ob_clean();

    check_ajax_referer( 'eduportal_nonce', 'nonce' );

    $nama   = sanitize_text_field( $_POST['nama']    ?? '' );
    $sekolah = sanitize_text_field( $_POST['sekolah'] ?? '' );

    if ( empty( $nama ) || empty( $sekolah ) ) {
        wp_send_json_error( array( 'msg' => 'Nama dan sekolah wajib diisi' ) );
    }

    global $wpdb;
    $result = $wpdb->insert(
        "{$wpdb->prefix}eduportal_peserta",
        array(
            'nama'    => $nama,
            'sekolah' => $sekolah,
            'kelas'   => sanitize_text_field( $_POST['kelas']  ?? '' ),
            'hp'      => sanitize_text_field( $_POST['hp']     ?? '' ),
            'jk'      => sanitize_text_field( $_POST['jk']     ?? '' ),
            'email'   => sanitize_email(      $_POST['email']  ?? '' ),
            'alamat'  => sanitize_textarea_field( $_POST['alamat'] ?? '' ),
            'tgl'     => current_time( 'Y-m-d' ),
            'status'  => 'pending',
        )
    );

    if ( $result === false ) {
        wp_send_json_error( array( 'msg' => 'Gagal menyimpan data' ) );
    }

    wp_send_json_success( array( 'msg' => 'Pendaftaran berhasil!', 'id' => $wpdb->insert_id ) );
}

/* ============================================================
   AJAX — Save (admin actions)
   ============================================================ */
add_action( 'wp_ajax_eduportal_save', 'eduportal_ajax_save' );
function eduportal_ajax_save() {
    if ( ob_get_length() ) ob_clean();

    check_ajax_referer( 'eduportal_nonce', 'nonce' );
    global $wpdb;

    $type = sanitize_text_field( $_POST['type'] ?? '' );

    switch ( $type ) {
        case 'kas':
            $wpdb->insert( "{$wpdb->prefix}eduportal_kas", array(
                'tgl'      => sanitize_text_field( $_POST['tgl'] ),
                'ket'      => sanitize_text_field( $_POST['ket'] ),
                'kategori' => sanitize_text_field( $_POST['kategori'] ),
                'jenis'    => sanitize_text_field( $_POST['jenis'] ),
                'jumlah'   => floatval( $_POST['jumlah'] ),
            ) );
            break;

        case 'kegiatan':
            $wpdb->insert( "{$wpdb->prefix}eduportal_kegiatan", array(
                'nama'   => sanitize_text_field( $_POST['nama'] ),
                'tgl'    => sanitize_text_field( $_POST['tgl'] ),
                'waktu'  => sanitize_text_field( $_POST['waktu'] ),
                'lokasi' => sanitize_text_field( $_POST['lokasi'] ),
                'tipe'   => sanitize_text_field( $_POST['tipe'] ),
                'desk'   => sanitize_textarea_field( $_POST['desk'] ),
            ) );
            break;

        case 'template':
            $wpdb->insert( "{$wpdb->prefix}eduportal_templates", array(
                'nama'        => sanitize_text_field( $_POST['nama'] ),
                'tipe'        => sanitize_text_field( $_POST['tipe'] ),
                'desk'        => sanitize_textarea_field( $_POST['desk'] ),
                'isi'         => sanitize_textarea_field( $_POST['isi'] ),
                'uploaded_by' => sanitize_text_field( $_POST['uploadedBy'] ),
            ) );
            break;

        case 'dokumen':
            $wpdb->insert( "{$wpdb->prefix}eduportal_dokumen", array(
                'judul'       => sanitize_text_field( $_POST['judul'] ),
                'template_id' => intval( $_POST['template_id'] ?? 0 ),
                'dibuat_oleh' => sanitize_text_field( $_POST['dibuat_oleh'] ),
                'konten'      => sanitize_textarea_field( $_POST['konten'] ),
            ) );
            break;

        case 'verifikasi':
            $wpdb->update(
                "{$wpdb->prefix}eduportal_peserta",
                array( 'status' => 'aktif' ),
                array( 'id'     => intval( $_POST['id'] ) )
            );
            break;

        case 'hapus_peserta':
            $wpdb->delete( "{$wpdb->prefix}eduportal_peserta",  array( 'id' => intval( $_POST['id'] ) ) );
            break;

        case 'hapus_kegiatan':
            $wpdb->delete( "{$wpdb->prefix}eduportal_kegiatan", array( 'id' => intval( $_POST['id'] ) ) );
            break;

        case 'hapus_template':
            $wpdb->delete( "{$wpdb->prefix}eduportal_templates", array( 'id' => intval( $_POST['id'] ) ) );
            break;

        default:
            wp_send_json_error( array( 'msg' => 'Tipe tidak dikenal: ' . $type ) );
            return;
    }

    wp_send_json_success( array( 'msg' => 'Berhasil disimpan', 'type' => $type ) );
}

/* ============================================================
   ADMIN MENU & SETTINGS
   ============================================================ */
add_action( 'admin_menu', 'eduportal_admin_menu' );
function eduportal_admin_menu() {
    add_menu_page(
        'EduPortal', 'EduPortal', 'manage_options',
        'eduportal', 'eduportal_admin_page',
        'dashicons-groups', 30
    );
    add_submenu_page( 'eduportal', 'Pengaturan', 'Pengaturan', 'manage_options', 'eduportal', 'eduportal_admin_page' );
    add_submenu_page( 'eduportal', 'Shortcode',  'Shortcode',  'manage_options', 'eduportal-sc', 'eduportal_sc_page' );
}

add_action( 'admin_init', 'eduportal_register_settings' );
function eduportal_register_settings() {
    $keys = array(
        'eduportal_org_name', 'eduportal_admin_pass',
        'eduportal_anggota_pass', 'eduportal_sheets_url', 'eduportal_sheets_id',
    );
    foreach ( $keys as $key ) {
        register_setting( 'eduportal_group', $key, array( 'sanitize_callback' => 'sanitize_text_field' ) );
    }
}

function eduportal_admin_page() {
    global $wpdb;
    ?>
    <div class="wrap">
    <h1>🎓 One-Stop Red Cross Portal — Pengaturan</h1>
    <form method="post" action="options.php">
    <?php settings_fields( 'eduportal_group' ); ?>
    <table class="form-table">
      <tr>
        <th scope="row">Nama Organisasi</th>
        <td><input type="text" name="eduportal_org_name" class="regular-text"
            value="<?php echo esc_attr( get_option( 'eduportal_org_name', get_bloginfo( 'name' ) ) ); ?>"></td>
      </tr>
      <tr>
        <th scope="row">Password Admin Portal</th>
        <td>
          <input type="text" name="eduportal_admin_pass" class="regular-text"
              value="<?php echo esc_attr( get_option( 'eduportal_admin_pass', 'admin123' ) ); ?>">
          <p class="description">⚠️ Segera ganti dari nilai default!</p>
        </td>
      </tr>
      <tr>
        <th scope="row">Password Anggota Portal</th>
        <td>
          <input type="text" name="eduportal_anggota_pass" class="regular-text"
              value="<?php echo esc_attr( get_option( 'eduportal_anggota_pass', 'anggota123' ) ); ?>">
        </td>
      </tr>
      <tr>
        <th scope="row">Google Sheets URL</th>
        <td>
          <input type="url" name="eduportal_sheets_url" class="large-text"
              value="<?php echo esc_url( get_option( 'eduportal_sheets_url', '' ) ); ?>">
          <p class="description">URL Apps Script deployment (opsional)</p>
        </td>
      </tr>
      <tr>
        <th scope="row">Spreadsheet ID</th>
        <td>
          <input type="text" name="eduportal_sheets_id" class="large-text"
              value="<?php echo esc_attr( get_option( 'eduportal_sheets_id', '' ) ); ?>">
        </td>
      </tr>
    </table>
    <?php submit_button( '💾 Simpan Pengaturan' ); ?>
    </form>

    <hr>
    <h2>📊 Statistik Database</h2>
    <table class="widefat" style="max-width:520px">
      <thead><tr><th>Tabel</th><th>Jumlah Data</th></tr></thead>
      <tbody>
      <?php
      $tables = array(
          'eduportal_peserta', 'eduportal_kas', 'eduportal_kegiatan',
          'eduportal_absensi', 'eduportal_templates', 'eduportal_dokumen',
      );
      foreach ( $tables as $t ) {
          $count = (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$wpdb->prefix}{$t}" );
          echo '<tr><td><code>' . esc_html( $wpdb->prefix . $t ) . '</code></td><td><strong>' . $count . '</strong></td></tr>';
      }
      ?>
      </tbody>
    </table>
    </div>
    <?php
}

function eduportal_sc_page() {
    ?>
    <div class="wrap">
    <h1>📋 Shortcode EduPortal</h1>
    <table class="widefat" style="max-width:700px">
      <thead><tr><th>Shortcode</th><th>Fungsi</th><th>Akses</th></tr></thead>
      <tbody>
        <tr><td><code>[eduportal]</code></td><td>Portal lengkap (login + semua modul)</td><td>Login required</td></tr>
        <tr><td><code>[eduportal_daftar]</code></td><td>Form pendaftaran peserta baru</td><td>Publik</td></tr>
        <tr><td><code>[eduportal_kegiatan]</code></td><td>Jadwal kegiatan mendatang</td><td>Publik</td></tr>
      </tbody>
    </table>

    <h2 style="margin-top:24px">📖 Cara Pasang</h2>
    <ol style="line-height:2.2;max-width:600px">
      <li>Buat halaman baru: <strong>Pages → Add New</strong></li>
      <li>Tambah blok <strong>Shortcode</strong> (cari di blok editor)</li>
      <li>Ketik shortcode, contoh: <code>[eduportal]</code></li>
      <li>Di sidebar kanan: <strong>Page Attributes</strong> → Template: <strong>Full Width</strong> (Astra)</li>
      <li>Klik <strong>Publish</strong></li>
    </ol>

    <div style="background:#FFF8DC;border-left:4px solid #F59E0B;padding:12px 16px;border-radius:4px;margin-top:16px;max-width:600px">
      <strong>💡 Tips Astra:</strong> Untuk halaman portal, gunakan Page Builder <em>Astra</em> → matikan Header & Footer
      agar portal tampil penuh tanpa elemen tema.
    </div>
    </div>
    <?php
}

/* ============================================================
   ELEMENTOR WIDGET
   ============================================================ */
add_action( 'elementor/widgets/register', 'eduportal_register_el_widget' );
function eduportal_register_el_widget( $widgets_manager ) {
    if ( ! class_exists( '\Elementor\Widget_Base' ) ) return;
    require_once EDUPORTAL_DIR . 'includes/elementor-widget.php';
    $widgets_manager->register( new EduPortal_Elementor_Widget() );
}
